import React from 'react';

const Footer =(props)=>{
   return(
        <footer>
          <p> Transportes x todos los derechos reservados</p>      
        </footer>);
}
export default Footer;