import '../../styles/components/layouts/Header.css'
import React from 'react';

const Header = (props)=>{
    return(
        <div className ="holder">
          <img src="images/logo.png" width="100" alt="transportes x"/>
            <h1> Transportes x</h1>
        </div>
    )
}
export default Header;